global N_LUT_TWIDDL;
global D_LUT_TWIDDLE;
global N_MID1;

N_MID1 = 24;

RMSE = zeros(13, 13);

for N_lut = 16:28
    for N_out = 16:28
        N_LUT_TWIDDL = N_lut;
        D_LUT_TWIDDLE = N_lut - 4;

        inputr = zeros(64, 1);
        inputi = zeros(64, 1);

        for t = 1:8
            xr = fi(rand(8, 1), 1, 16, 15);
            xi = fi(rand(8, 1), 1, 16, 15);
            x_double = complex(double(xr), double(xi));
            input = fft(x_double);
            inputr(8*t-7:8*t) = real(input);
            inputi(8*t-7:8*t) = imag(input);
        end

        inputr = fi(inputr, 1, 24, 20);
        inputi = fi(inputi, 1, 24, 20);
        input = complex(double(inputr), double(inputi));

        outputr = zeros(64, 1);
        outputi = zeros(64, 1);
        standard_out = zeros(64, 1);

        for n = 0:7
            for k = 0:7
                [outputr(8*n+k+1), outputi(8*n+k+1)] = twiddle(inputr(8*n+k+1), inputi(8*n+k+1), n, k, N_out);
                standard_out(8*n+k+1) = input(8*n+k+1) * exp(-1i*2*pi*n*k/64);
            end
        end
        outputr = fi(outputr, 1, N_out, N_out-4);
        outputi = fi(outputi, 1, N_out, N_out-4);
        output = complex(double(outputr), double(outputi));
        RMSE(N_lut-15, N_out-15) = sqrt(mean(abs(output - standard_out).^2));
    end
    delete('*.mat');
end


